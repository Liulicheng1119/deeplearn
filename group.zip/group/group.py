import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_curve, auc, confusion_matrix, classification_report

# --- 1. 加载真实数据集 ---
# 注意：你需要先下载数据集到当前目录或指定路径
# 数据集可以从UCI Machine Learning Repository获取

try:
    # 方式1：从Excel文件读取
    df = pd.read_excel('default of credit card clients.xls', header=1, index_col=0)

    # 或者如果Excel文件有多个工作表，可以指定：
    # df = pd.read_excel('default of credit card clients.xls', sheet_name='Data', header=1)

    print(f"✅ 成功加载真实数据集: {df.shape[0]} 行, {df.shape[1]} 列")

except FileNotFoundError:
    print("❌ 未找到数据集文件，请确保 'default of credit card clients.xls' 在当前目录")
    print("📥 可以从这里下载: https://archive.ics.uci.edu/ml/datasets/default+of+credit+card+clients")
    exit()

# 检查数据集
print("\n数据集基本信息:")
print(df.info())
print("\n前5行数据:")
print(df.head())
print("\n目标变量分布:")
print(df['default payment next month'].value_counts(normalize=True))

# 重命名列以便更好理解（可选）
# 数据集特征说明：X1-X23是各种特征，最后的Y是目标变量
df.rename(columns={'default payment next month': 'Y'}, inplace=True)

# --- 2. 数据预处理 ---
# 检查缺失值
print(f"\n缺失值统计:\n{df.isnull().sum().sum()} 个缺失值")

# 删除ID列（如果有的话）
if 'ID' in df.columns:
    df = df.drop('ID', axis=1)

# 分离特征和目标
# 注意：原始数据集中，'Y'是目标变量，其他都是特征
X = df.drop('Y', axis=1)
y = df['Y']

# 检查特征名称
print(f"\n特征数量: {X.shape[1]}")
print(f"特征名称: {list(X.columns[:10])}...")

# --- 3. 探索性数据分析 (EDA) ---
plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
sns.countplot(x='Y', data=df, palette='viridis')
plt.title('Credit Card Default Distribution')
plt.xlabel('Default (1) vs Non-default (0)')
plt.ylabel('Count')

plt.subplot(1, 2, 2)
# 选取几个重要特征查看相关性
# LIMIT_BAL（信用额度）、AGE（年龄）、BILL_AMT1（最近账单金额）等
if 'LIMIT_BAL' in X.columns and 'AGE' in X.columns:
    selected_features = ['LIMIT_BAL', 'AGE', 'BILL_AMT1', 'PAY_0', 'Y']
    sns.heatmap(df[selected_features].corr(), annot=True, cmap='RdBu', fmt='.2f')
    plt.title('Feature Correlation (Selected Features)')
plt.tight_layout()
plt.show()

# 额外EDA：查看数值特征的分布
if 'LIMIT_BAL' in X.columns:
    plt.figure(figsize=(10, 4))
    plt.subplot(1, 2, 1)
    sns.histplot(df[df['Y'] == 0]['LIMIT_BAL'], color='blue', label='Non-default', alpha=0.5)
    sns.histplot(df[df['Y'] == 1]['LIMIT_BAL'], color='red', label='Default', alpha=0.5)
    plt.title('Credit Limit Distribution by Class')
    plt.legend()

    plt.subplot(1, 2, 2)
    sns.boxplot(x='Y', y='AGE', data=df)
    plt.title('Age Distribution by Default Status')
    plt.tight_layout()
    plt.show()

# --- 4. 数据分割与标准化 ---
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

# 检查分割后的类别分布
print(f"\n训练集类别分布:\n{y_train.value_counts(normalize=True)}")
print(f"\n测试集类别分布:\n{y_test.value_counts(normalize=True)}")

scaler = StandardScaler()
X_train_s = scaler.fit_transform(X_train)
X_test_s = scaler.transform(X_test)

# 转换为 PyTorch 张量
X_train_t = torch.FloatTensor(X_train_s)
y_train_t = torch.FloatTensor(y_train.values).view(-1, 1)
X_test_t = torch.FloatTensor(X_test_s)
y_test_t = torch.FloatTensor(y_test.values).view(-1, 1)

train_loader = DataLoader(TensorDataset(X_train_t, y_train_t), batch_size=64, shuffle=True)


# --- 5. 方法一：PyTorch 深度学习分类模型 ---
class CreditNet(nn.Module):
    def __init__(self, input_dim):
        super(CreditNet, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.ReLU(),
            nn.Dropout(0.3),  # 略微增加dropout以防止过拟合
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(32, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        return self.net(x)


pt_model = CreditNet(X_train_s.shape[1])
criterion = nn.BCELoss()
optimizer = optim.Adam(pt_model.parameters(), lr=0.001, weight_decay=1e-5)  # 添加L2正则化

# 添加学习率调度器
scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.1)

# 训练模型
print("\n开始训练 PyTorch 模型...")
epochs = 30
train_losses = []

for epoch in range(epochs):
    pt_model.train()
    epoch_loss = 0
    for batch_x, batch_y in train_loader:
        optimizer.zero_grad()
        outputs = pt_model(batch_x)
        loss = criterion(outputs, batch_y)
        loss.backward()
        optimizer.step()
        epoch_loss += loss.item()

    scheduler.step()
    avg_loss = epoch_loss / len(train_loader)
    train_losses.append(avg_loss)

    if (epoch + 1) % 5 == 0:
        print(f"Epoch {epoch + 1}/{epochs}, Loss: {avg_loss:.4f}, LR: {scheduler.get_last_lr()[0]:.6f}")

# 绘制训练损失曲线
plt.figure(figsize=(8, 4))
plt.plot(train_losses, label='Training Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.title('PyTorch Model Training Loss')
plt.legend()
plt.grid(True, alpha=0.3)
plt.show()

# --- 6. 方法二：随机森林对比 ---
print("\n开始训练随机森林模型...")
rf_model = RandomForestClassifier(
    n_estimators=100,
    max_depth=10,  # 限制深度以防止过拟合
    min_samples_split=50,
    class_weight='balanced',  # 处理类别不平衡
    random_state=42,
    n_jobs=-1
)
rf_model.fit(X_train_s, y_train)

# 输出特征重要性（随机森林）
if hasattr(rf_model, 'feature_importances_'):
    feature_importance = pd.DataFrame({
        'feature': X.columns,
        'importance': rf_model.feature_importances_
    }).sort_values('importance', ascending=False)

    print("\nTop 10重要特征:")
    print(feature_importance.head(10))

    # 可视化特征重要性
    plt.figure(figsize=(10, 6))
    plt.barh(feature_importance['feature'][:15][::-1],
             feature_importance['importance'][:15][::-1])
    plt.xlabel('Importance')
    plt.title('Top 15 Feature Importance (Random Forest)')
    plt.tight_layout()
    plt.show()

# --- 7. 结果评估与可视化对比 ---
pt_model.eval()
with torch.no_grad():
    pt_probs = pt_model(X_test_t).numpy()

rf_probs = rf_model.predict_proba(X_test_s)[:, 1]

# 计算ROC曲线和AUC
fpr_pt, tpr_pt, _ = roc_curve(y_test, pt_probs)
fpr_rf, tpr_rf, _ = roc_curve(y_test, rf_probs)

auc_pt = auc(fpr_pt, tpr_pt)
auc_rf = auc(fpr_rf, tpr_rf)

# 绘制ROC曲线对比
plt.figure(figsize=(10, 8))
plt.subplot(2, 2, 1)
plt.plot(fpr_pt, tpr_pt, label=f'PyTorch MLP (AUC = {auc_pt:.3f})', linewidth=2)
plt.plot(fpr_rf, tpr_rf, label=f'Random Forest (AUC = {auc_rf:.3f})', linewidth=2)
plt.plot([0, 1], [0, 1], 'k--', alpha=0.5)
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve Comparison')
plt.legend()
plt.grid(True, alpha=0.3)

# 绘制Precision-Recall曲线
from sklearn.metrics import precision_recall_curve, average_precision_score

precision_pt, recall_pt, _ = precision_recall_curve(y_test, pt_probs)
precision_rf, recall_rf, _ = precision_recall_curve(y_test, rf_probs)
ap_pt = average_precision_score(y_test, pt_probs)
ap_rf = average_precision_score(y_test, rf_probs)

plt.subplot(2, 2, 2)
plt.plot(recall_pt, precision_pt, label=f'PyTorch MLP (AP = {ap_pt:.3f})', linewidth=2)
plt.plot(recall_rf, precision_rf, label=f'Random Forest (AP = {ap_rf:.3f})', linewidth=2)
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.title('Precision-Recall Curve')
plt.legend()
plt.grid(True, alpha=0.3)

# 绘制混淆矩阵（PyTorch模型）
plt.subplot(2, 2, 3)
pt_preds = (pt_probs > 0.5).astype(int)
cm_pt = confusion_matrix(y_test, pt_preds)
sns.heatmap(cm_pt, annot=True, fmt='d', cmap='Blues')
plt.title(f'PyTorch Confusion Matrix\nThreshold=0.5')
plt.ylabel('Actual')
plt.xlabel('Predicted')

# 绘制混淆矩阵（随机森林）
plt.subplot(2, 2, 4)
rf_preds = rf_model.predict(X_test_s)
cm_rf = confusion_matrix(y_test, rf_preds)
sns.heatmap(cm_rf, annot=True, fmt='d', cmap='Greens')
plt.title('Random Forest Confusion Matrix')
plt.ylabel('Actual')
plt.xlabel('Predicted')

plt.tight_layout()
plt.show()

# --- 8. 输出详细评估报告 ---
print("\n" + "=" * 50)
print("模型性能对比总结")
print("=" * 50)

print(f"\n1. AUC分数:")
print(f"   PyTorch MLP: {auc_pt:.4f}")
print(f"   随机森林:    {auc_rf:.4f}")

print(f"\n2. Average Precision分数:")
print(f"   PyTorch MLP: {ap_pt:.4f}")
print(f"   随机森林:    {ap_rf:.4f}")

print("\n3. 详细分类报告:")

print("\n--- PyTorch Model Report ---")
print(classification_report(y_test, pt_preds, target_names=['Non-default', 'Default']))

print("\n--- Random Forest Report ---")
print(classification_report(y_test, rf_preds, target_names=['Non-default', 'Default']))

# --- 9. 不同阈值下的性能分析 ---
print("\n4. PyTorch模型在不同阈值下的表现:")
thresholds = [0.3, 0.4, 0.5, 0.6, 0.7]
for thresh in thresholds:
    preds = (pt_probs > thresh).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_test, preds).ravel()

    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
    sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0

    print(f"\n阈值 {thresh}:")
    print(f"  特异度(Specificity): {specificity:.3f}")
    print(f"  灵敏度(Sensitivity/Recall): {sensitivity:.3f}")
    print(f"  Precision: {tp / (tp + fp):.3f}" if (tp + fp) > 0 else "  Precision: 0.000")